//
//  constantes.cpp
//  PROJET PROG
//
//  Created by Pascal Epple on 28.03.18.
//  Copyright © 2018 Pascal Epple. All rights reserved.
//

#include "vecteur.h"

extern const Vecteur g(0.0, 0.0, -9.81);
