# frappuccino
Projet de programmation EPFL 2018 Bachelor Mathématiques (Première première)

###SALUT
On a un problème avec remettre à 0 qui est dans le protected et on est pas sûr d'avoir capté comment utiliser le friend, on a du mal avec QTCreator.
