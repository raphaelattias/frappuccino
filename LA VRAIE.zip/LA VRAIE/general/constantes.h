//
//  constantes.hpp
//  PROJET PROG
//
//  Created by Pascal Epple on 28.03.18.
//  Copyright © 2018 Pascal Epple. All rights reserved.
//


#pragma once
#include "vecteur.h"

extern const Vecteur g;
