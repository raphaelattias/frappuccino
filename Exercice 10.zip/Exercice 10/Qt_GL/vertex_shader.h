#ifndef VERTEX_SHADER_H
#define VERTEX_SHADER_H

enum Vertex_Shader_Attribute_Id {
  SommetId = 0,
  CouleurId,
};

#endif
