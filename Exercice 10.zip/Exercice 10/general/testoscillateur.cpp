//
//  testoscillateur.cpp
//  PROJET
//
//  Created by Raphael Attias on 14/03/2018.
//  Copyright © 2018 Raphael Attias. All rights reserved.
//
/*
#include <stdio.h>
#include "vecteur.h"
#include <iostream>
#include <vector>
#include <cmath>

using namespace std;

int main(){
    
    Vecteur v2(1,2,5);
    Vecteur v1(3,2,1);
    
    double i;
    i = (v2 * v1);
    cout << i;
    
    return 0;
};
*/
