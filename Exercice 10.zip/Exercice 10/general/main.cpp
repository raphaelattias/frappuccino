//
//  main.cpp
//  PROJET PROG
//
//  Created by Pascal Epple on 17.03.18.
//  Copyright © 2018 Pascal Epple. All rights reserved.
//

/*
#include <stdio.h>
#include "vecteur.h"
#include "Oscillateur.h"

#include <iostream>
#include <vector>
#include <cmath>

using namespace std;



int main(){
    Vecteur v3({1.0,4.0,5.5,3.2,5.5});
    cout << v3 << endl;
    Vecteur v1 ({1.0, 4.0, 3.6, 2.5, 5.0, 2.3});
    cout << v1 << endl;
    Vecteur v2;
    v2 = v1.soustraction(v3);
    Oscillateur o1;
    o1.set_vecteurs(v1, v2);
    cout << endl;
    Vecteur v4;
    v4 = o1.evolution(10);
    o1.afficher_evolution();
    cout << v4 << endl;
    return 0;
}
 
 */
